﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Проект
{
    class InvalidCharException : Exception
    {
       
    }

    class InvalidEmptyException : Exception
    {

    }
    class InvalidNameException : Exception 
    {

    }
}
