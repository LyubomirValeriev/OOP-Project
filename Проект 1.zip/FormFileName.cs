﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Проект
{
    public partial class FormFileName : Form
    {
        private string _fileName;
        public string fileName
        {
            get => _fileName;
            set
            {
                if (string.IsNullOrEmpty(textBoxFileName.Text))
                    throw new InvalidEmptyException();
                /*
                for (int i = 0; i < value.Length; i++)
                {
                    if (value[i] == '>' || value[i] == '<' || value[i] == '"' || value[i] == '*' || value[i] == '/' || value[i] == '|')
                        throw new InvalidCharException();
                }*/

                if (File.Exists(value))
                    throw new InvalidNameException();
                _fileName = value;
            }
        }

        public FormFileName()
        {
            InitializeComponent();
        }

        private void buttonOk_Click(object sender, EventArgs e)
        {
            try
            {
                fileName = textBoxFileName.Text.ToString();
            }
            catch (InvalidCharException)
            {
                MessageBox.Show("Името на файла не може да съдържа някой то следните знаци : \n  >, <,? ,* ,/ ,| ,:", "Error ",
                    MessageBoxButtons.OK, MessageBoxIcon.Error
                    );
                return;
            }
            catch (InvalidEmptyException)
            {
                MessageBox.Show("Файлът трябва да има име !", "Error ",
                  MessageBoxButtons.OK, MessageBoxIcon.Error
                  );
                return;
            }
            catch (InvalidNameException)
            {
                MessageBox.Show("Файл с такова име вече съществува !", "Error ",
                  MessageBoxButtons.OK, MessageBoxIcon.Error
                  );
                return;
            }

            DialogResult = DialogResult.OK;

        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            return;
        }


        private void textBoxFileName_KeyPress(object sender, KeyPressEventArgs e)
        {/*
            if (e.KeyChar == '>' ||
                e.KeyChar == '<' ||
                e.KeyChar == '"' ||
                e.KeyChar == '*' ||
                e.KeyChar == '/' ||
               e.KeyChar == '|')
            {
                MessageBox.Show("Името на файла не може да съдържа някой то следните знаци : \n  >, <,? ,* ,/ ,| ,:", "Error ",
                     MessageBoxButtons.OK, MessageBoxIcon.Error
                     );
                
                var a = textBoxFileName.Text;
                
                if (a.Length > 0)
                    textBoxFileName.Text = a.Remove(a.Length - 2, 1);
                else
                    textBoxFileName.Text = textBoxFileName.Text.Substring(0, (textBoxFileName.Text.Length));
                textBoxFileName.Text = a; 
            }
            //   throw new InvalidCharException();
            */
        }

     

        private void textBoxFileName_KeyUp(object sender, KeyEventArgs e)
        {
            var a = textBoxFileName.Text;
            if (e.KeyCode == Keys.Multiply || e.KeyCode == Keys.)
            {
                if (a.Length > 0)
                    a = a.Substring(0, a.Length - 1); 
            }
            textBoxFileName.Text = a; 
        }
    }
}
